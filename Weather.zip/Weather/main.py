
import requests

url = "https://api.open-meteo.com/v1/forecast"

params = {
    "latitude": 11.34,
    "longitude": 77.72,
    "current": "temperature_2m,wind_speed_10m"
}

response = requests.get(url, params=params, timeout=10)

if response.status_code == 200:
    data = response.json()

    temperature = data["current"]["temperature_2m"]
    wind_speed = data["current"]["wind_speed_10m"]

    print("Temperature:", temperature, "°C")
    print("Wind Speed:", wind_speed, "km/h")

else:
    print("API request failed:", response.status_code)

